import React, { useEffect, useMemo, useRef, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Switch,
  Animated,
} from 'react-native';

const STORAGE_USER_KEY = 'cf_user';
const STORAGE_TRANSACTIONS_KEY = 'cf_transactions';
const STORAGE_THEME_KEY = 'cf_theme';

const themes = {
  light: {
    primary: '#f5b301',
    primaryDark: '#d89e00',
    surface: '#0f172a',
    text: '#0f172a',
    muted: '#4b5563',
    gray: '#eef2f6', // inputs / pills
    light: '#f9fbff', // page background
    card: '#ffffff',
    danger: '#ef4444',
    border: '#dde3ea',
    shadowOpacity: 0.06,
    hint: '#94a3b8',
    subtle: '#f6f7fb',
  },
  dark: {
    primary: '#f5b301',
    primaryDark: '#ffc107',
    surface: '#0b0f14', // hero
    text: '#e5e7eb',
    muted: '#9ca3af',
    gray: '#151a22', // inputs / pills
    light: '#080b11', // page background
    card: '#0f141d',
    danger: '#f87171',
    border: '#1f2530',
    shadowOpacity: 0.25,
    hint: '#cbd5e1',
    subtle: '#111827',
  },
};

const formatCurrency = (value) =>
  `R$ ${Number(value || 0).toFixed(2).replace('.', ',')}`;

export default function App() {
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState('login'); // login | signup
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [signupForm, setSignupForm] = useState({ name: '', email: '', password: '' });
  const [transactions, setTransactions] = useState([]);
  const [newTx, setNewTx] = useState({ description: '', amount: '', type: 'expense' });
  const [authError, setAuthError] = useState('');
  const [txError, setTxError] = useState('');
  const [theme, setTheme] = useState('dark');
  const [activeTab, setActiveTab] = useState('home'); // ainda usado para FAB focar formulário
  const scrollRef = useRef(null);
  const descInputRef = useRef(null);
  const [formOffset, setFormOffset] = useState(0);
  const drawerWidth = 360;
  const drawerAnim = useRef(new Animated.Value(-drawerWidth)).current;
  const [drawerOpen, setDrawerOpen] = useState(false);

  const colors = useMemo(() => themes[theme], [theme]);
  const styles = useMemo(() => createStyles(colors), [colors]);

  const TransactionItem = ({ item }) => (
    <View style={[styles.transactionItem, item.type === 'expense' && styles.expenseItem]}>
      <View>
        <Text style={styles.transactionTitle}>{item.description}</Text>
        <Text style={styles.transactionDate}>{item.date}</Text>
      </View>
      <Text style={[styles.transactionValue, item.type === 'expense' && styles.expenseValue]}>
        {item.type === 'expense' ? '-' : '+'} {formatCurrency(item.amount)}
      </Text>
    </View>
  );

  useEffect(() => {
    const loadStoredData = async () => {
      try {
        const [userStored, txStored, themeStored] = await Promise.all([
          AsyncStorage.getItem(STORAGE_USER_KEY),
          AsyncStorage.getItem(STORAGE_TRANSACTIONS_KEY),
          AsyncStorage.getItem(STORAGE_THEME_KEY),
        ]);
        if (userStored) setUser(JSON.parse(userStored));
        if (txStored) setTransactions(JSON.parse(txStored));
        if (themeStored === 'dark' || themeStored === 'light') {
          setTheme(themeStored);
        }
      } catch (err) {
        setAuthError('Não foi possível carregar seus dados locais.');
      }
    };
    loadStoredData();
  }, []);

  useEffect(() => {
    if (!user) return;
    AsyncStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_TRANSACTIONS_KEY, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_THEME_KEY, theme);
  }, [theme]);

  const totals = useMemo(() => {
    const income = transactions
      .filter((t) => t.type === 'income')
      .reduce((acc, cur) => acc + Number(cur.amount), 0);
    const expense = transactions
      .filter((t) => t.type === 'expense')
      .reduce((acc, cur) => acc + Number(cur.amount), 0);
    return { income, expense, balance: income - expense };
  }, [transactions]);

  const currentMonthLabel = useMemo(() => {
    const now = new Date();
    return now.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  }, []);

  const monthlyReport = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const sameMonth = (tx) => {
      let d;
      if (tx.isoDate) {
        d = new Date(tx.isoDate);
      } else if (tx.date && tx.date.includes('/')) {
        const [dd, mm, yyyy] = tx.date.split('/');
        d = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
      } else {
        return false;
      }
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    };

    const monthExpenses = transactions.filter(
      (t) => t.type === 'expense' && sameMonth(t),
    );

    const total = monthExpenses.reduce((acc, cur) => acc + Number(cur.amount), 0);
    const count = monthExpenses.length;
    const top5 = monthExpenses.slice(0, 5);

    return { total, count, top5 };
  }, [transactions]);

  const handleSignup = async () => {
    setAuthError('');
    if (!signupForm.name || !signupForm.email || !signupForm.password) {
      setAuthError('Preencha todos os campos.');
      return;
    }
    const newUser = {
      name: signupForm.name.trim(),
      email: signupForm.email.trim().toLowerCase(),
      password: signupForm.password,
    };
    await AsyncStorage.setItem(STORAGE_USER_KEY, JSON.stringify(newUser));
    setUser(newUser);
    setLoginForm({ email: newUser.email, password: '' });
    setSignupForm({ name: '', email: '', password: '' });
  };

  const handleLogin = async () => {
    setAuthError('');
    const stored = await AsyncStorage.getItem(STORAGE_USER_KEY);
    if (!stored) {
      setAuthError('Nenhum usuário cadastrado. Crie sua conta.');
      setAuthMode('signup');
      return;
    }
    const parsed = JSON.parse(stored);
    const email = loginForm.email.trim().toLowerCase();
    if (parsed.email !== email || parsed.password !== loginForm.password) {
      setAuthError('Credenciais inválidas.');
      return;
    }
    setUser(parsed);
    setLoginForm({ email: '', password: '' });
  };

  const handleLogout = async () => {
    setUser(null);
  };

  const handleAddTransaction = () => {
    setTxError('');
    if (!newTx.description || !newTx.amount) {
      setTxError('Descrição e valor são obrigatórios.');
      return;
    }
    const normalizedAmount = newTx.amount.replace(',', '.');
    const amountNumber = Number(normalizedAmount);
    if (Number.isNaN(amountNumber) || amountNumber <= 0) {
      setTxError('Informe um valor válido.');
      return;
    }
    const now = new Date();
    const entry = {
      id: Date.now().toString(),
      description: newTx.description,
      amount: amountNumber,
      type: newTx.type,
      date: now.toLocaleDateString('pt-BR'),
      isoDate: now.toISOString(),
    };
    setTransactions((prev) => [entry, ...prev]);
    setNewTx({ description: '', amount: '', type: newTx.type });
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const openDrawer = () => {
    setDrawerOpen(true);
    Animated.timing(drawerAnim, {
      toValue: 0,
      duration: 220,
      useNativeDriver: true,
    }).start();
  };

  const closeDrawer = () => {
    Animated.timing(drawerAnim, {
      toValue: -drawerWidth,
      duration: 200,
      useNativeDriver: true,
    }).start(() => setDrawerOpen(false));
  };

  const AuthBlock = () => (
    <View style={styles.authCard}>
      <Text style={styles.title}>Organize suas finanças</Text>
      <Text style={styles.subtitle}>
        Inspirado no Organizze, com login salvo em armazenamento local.
      </Text>
      {authMode === 'signup' && (
      <TextInput
        style={styles.input}
        placeholder="Seu nome"
        placeholderTextColor={colors.muted}
          blurOnSubmit={false}
          returnKeyType="next"
        onSubmitEditing={() => {}}
          value={signupForm.name}
          onChangeText={(text) => setSignupForm((prev) => ({ ...prev, name: text }))}
        />
      )}
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor={colors.muted}
        autoCapitalize="none"
        autoCorrect={false}
        autoComplete="email"
        keyboardType="email-address"
        blurOnSubmit={false}
        returnKeyType="next"
        onSubmitEditing={() => {}}
        value={authMode === 'login' ? loginForm.email : signupForm.email}
        onChangeText={(text) =>
          authMode === 'login'
            ? setLoginForm((prev) => ({ ...prev, email: text }))
            : setSignupForm((prev) => ({ ...prev, email: text }))
        }
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        placeholderTextColor={colors.muted}
        secureTextEntry
        autoCorrect={false}
        autoComplete={authMode === 'login' ? 'password' : 'new-password'}
        blurOnSubmit={false}
        returnKeyType="done"
        onSubmitEditing={() => {}}
        value={authMode === 'login' ? loginForm.password : signupForm.password}
        onChangeText={(text) =>
          authMode === 'login'
            ? setLoginForm((prev) => ({ ...prev, password: text }))
            : setSignupForm((prev) => ({ ...prev, password: text }))
        }
      />
      {authError ? <Text style={styles.error}>{authError}</Text> : null}
      {authMode === 'login' ? (
        <TouchableOpacity style={styles.primaryButton} onPress={handleLogin}>
          <Text style={styles.primaryButtonText}>Entrar</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={styles.primaryButton} onPress={handleSignup}>
          <Text style={styles.primaryButtonText}>Criar conta</Text>
        </TouchableOpacity>
      )}
      <TouchableOpacity
        onPress={() => {
          setAuthError('');
          setAuthMode((prev) => (prev === 'login' ? 'signup' : 'login'));
        }}
      >
        <Text style={styles.link}>
          {authMode === 'login' ? 'Criar conta' : 'Já tenho conta'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  const scrollToForm = () => {
    setActiveTab('home');
    setTimeout(() => {
      if (formOffset && scrollRef.current?.scrollTo) {
        scrollRef.current.scrollTo({ y: Math.max(formOffset - 12, 0), animated: true });
      }
      descInputRef.current?.focus?.();
    }, 120);
  };

  const Dashboard = () => (
    <View style={styles.dashboard}>
      <View style={styles.header}>
        <View>
          <Text style={styles.welcome}>Olá, {user?.name || 'visitante'}</Text>
          <Text style={styles.subtitle}>Seu dinheiro sob controle.</Text>
        </View>
        <TouchableOpacity style={styles.avatarButton} onPress={openDrawer}>
          <Text style={styles.avatarButtonText}>
            {user?.name ? user.name.slice(0, 1).toUpperCase() : 'U'}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.cardsContainer}>
        <View style={[styles.card, styles.balanceCard]}>
          <Text style={styles.cardLabel}>Saldo</Text>
          <Text style={styles.balanceValue}>{formatCurrency(totals.balance)}</Text>
          <Text style={styles.cardHint}>
            {totals.balance >= 0 ? 'Tudo em ordem' : 'Atenção aos gastos'}
          </Text>
        </View>
        <View style={styles.row}>
          <View style={[styles.card, styles.smallCard]}>
            <Text style={styles.cardLabel}>Entradas</Text>
            <Text style={[styles.cardValue, { color: colors.primary }]}>
              {formatCurrency(totals.income)}
            </Text>
          </View>
          <View style={[styles.card, styles.smallCard]}>
            <Text style={styles.cardLabel}>Saídas</Text>
            <Text style={[styles.cardValue, { color: colors.danger }]}>
              {formatCurrency(totals.expense)}
            </Text>
          </View>
        </View>
        <View style={[styles.card, styles.reportCard]}>
          <View style={styles.reportHeader}>
            <View>
              <Text style={styles.cardLabel}>Relatório Mensal</Text>
              <Text style={styles.reportSubtitle}>{currentMonthLabel}</Text>
            </View>
            <View style={styles.reportBadge}>
              <Text style={styles.reportBadgeText}>
                {monthlyReport.count} despesa{monthlyReport.count === 1 ? '' : 's'}
              </Text>
            </View>
          </View>
          <Text style={styles.reportTotal}>{formatCurrency(monthlyReport.total)}</Text>
          <Text style={styles.reportHint}>Total de despesas do mês</Text>
          <View style={styles.reportList}>
            {monthlyReport.top5.length === 0 ? (
              <Text style={styles.empty}>Sem despesas este mês.</Text>
            ) : (
              monthlyReport.top5.map((item) => (
                <View key={item.id} style={styles.reportItem}>
                  <View>
                    <Text style={styles.transactionTitle}>{item.description}</Text>
                    <Text style={styles.transactionDate}>{item.date}</Text>
                  </View>
                  <Text style={[styles.transactionValue, styles.expenseValue]}>
                    - {formatCurrency(item.amount)}
                  </Text>
                </View>
              ))
            )}
          </View>
        </View>
        <View style={[styles.card, styles.overviewCard]}>
          <Text style={styles.sectionTitle}>Visão geral do mês</Text>
          <View style={styles.overviewRow}>
            <View style={[styles.bar, { backgroundColor: '#22c55e' }]} />
            <Text style={styles.overviewLabel}>Receitas</Text>
            <Text style={styles.overviewValue}>{formatCurrency(monthlyReport.total ? totals.income : totals.income)}</Text>
          </View>
          <View style={styles.overviewRow}>
            <View style={[styles.bar, { backgroundColor: '#ef4444' }]} />
            <Text style={styles.overviewLabel}>Despesas</Text>
            <Text style={styles.overviewValue}>{formatCurrency(monthlyReport.total)}</Text>
          </View>
          <View style={styles.overviewRow}>
            <View style={[styles.bar, { backgroundColor: '#a855f7' }]} />
            <Text style={styles.overviewLabel}>Despesas no crédito</Text>
            <Text style={styles.overviewValue}>R$ 0,00</Text>
          </View>
        </View>
        <View style={[styles.card, styles.alertCard]}>
          <Text style={styles.sectionTitle}>Pendências e alertas</Text>
          <View style={styles.overviewRow}>
            <View style={[styles.barSmall, { backgroundColor: '#22c55e' }]} />
            <Text style={styles.overviewLabel}>Receitas pendentes</Text>
            <Text style={styles.overviewValue}>R$ 0,00</Text>
          </View>
          <View style={styles.overviewRow}>
            <View style={[styles.barSmall, { backgroundColor: '#ef4444' }]} />
            <Text style={styles.overviewLabel}>Despesas pendentes</Text>
            <Text style={styles.overviewValue}>R$ 0,00</Text>
          </View>
          <View style={styles.overviewRow}>
            <View style={[styles.barSmall, { backgroundColor: '#6366f1' }]} />
            <Text style={styles.overviewLabel}>Faturas de cartão</Text>
            <Text style={styles.overviewValue}>R$ 0,00</Text>
          </View>
          <View style={styles.overviewRow}>
            <View style={[styles.barSmall, { backgroundColor: '#0ea5e9' }]} />
            <Text style={styles.overviewLabel}>Saldo seguro</Text>
            <Text style={styles.overviewValue}>{formatCurrency(totals.balance)}</Text>
          </View>
        </View>
      </View>

      <View
        style={styles.formCard}
        onLayout={({ nativeEvent }) => setFormOffset(nativeEvent.layout.y)}
      >
        <Text style={styles.sectionTitle}>Novo lançamento</Text>
        <View style={styles.row}>
          <TouchableOpacity
            style={[
              styles.chip,
              newTx.type === 'expense' && styles.chipActiveExpense,
            ]}
            onPress={() => setNewTx((prev) => ({ ...prev, type: 'expense' }))}
          >
            <Text
              style={[
                styles.chipText,
                newTx.type === 'expense' && styles.chipTextActive,
              ]}
            >
              Despesa
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.chip,
              newTx.type === 'income' && styles.chipActiveIncome,
            ]}
            onPress={() => setNewTx((prev) => ({ ...prev, type: 'income' }))}
          >
            <Text
              style={[
                styles.chipText,
                newTx.type === 'income' && styles.chipTextActive,
              ]}
            >
              Receita
            </Text>
          </TouchableOpacity>
        </View>
        <TextInput
          style={styles.input}
          placeholder="Descrição (ex: Mercado)"
          placeholderTextColor={colors.muted}
          blurOnSubmit={false}
          returnKeyType="next"
        onSubmitEditing={() => {}}
          ref={descInputRef}
          value={newTx.description}
          onChangeText={(text) => setNewTx((prev) => ({ ...prev, description: text }))}
        />
        <TextInput
          style={styles.input}
          placeholder="Valor"
          placeholderTextColor={colors.muted}
          keyboardType="numeric"
          inputMode="decimal"
          blurOnSubmit={false}
          returnKeyType="done"
        onSubmitEditing={() => {}}
          value={newTx.amount}
          onChangeText={(text) => setNewTx((prev) => ({ ...prev, amount: text }))}
        />
        {txError ? <Text style={styles.error}>{txError}</Text> : null}
        <TouchableOpacity style={styles.primaryButton} onPress={handleAddTransaction}>
          <Text style={styles.primaryButtonText}>Adicionar</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.listCard}>
        <Text style={styles.sectionTitle}>Últimos lançamentos</Text>
        {transactions.length === 0 ? (
          <Text style={styles.empty}>Nenhum lançamento ainda.</Text>
        ) : (
          <FlatList
            data={transactions}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <TransactionItem item={item} />}
          />
        )}
      </View>
    </View>
  );

  const Profile = () => (
    <View style={styles.profileWrapper}>
      <View style={styles.profileSidebar}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {user?.name ? user.name.slice(0, 1).toUpperCase() : 'U'}
          </Text>
        </View>
        <View style={styles.sidebarItem}>
          <Text style={styles.sidebarIcon}>👤</Text>
          <Text style={styles.sidebarText}>Conta</Text>
        </View>
        <View style={styles.sidebarItem}>
          <Text style={styles.sidebarIcon}>💬</Text>
          <Text style={styles.sidebarText}>Mensagens</Text>
        </View>
        <View style={styles.sidebarItem}>
          <Text style={styles.sidebarIcon}>📚</Text>
          <Text style={styles.sidebarText}>Ajuda</Text>
        </View>
        <TouchableOpacity style={styles.sidebarLogout} onPress={handleLogout}>
          <Text style={styles.sidebarIcon}>⏻</Text>
          <Text style={styles.sidebarLogoutText}>Sair</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.profileCard}>
        <Text style={styles.sectionTitle}>Perfil</Text>
        <View style={styles.profileRow}>
          <Text style={styles.profileLabel}>Nome</Text>
          <Text style={styles.profileValue}>{user?.name || 'Não definido'}</Text>
        </View>
        <View style={styles.profileRow}>
          <Text style={styles.profileLabel}>Email</Text>
          <Text style={styles.profileValue}>{user?.email || 'Não definido'}</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.profileRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.profileLabel}>Tema</Text>
            <Text style={styles.profileHint}>
              Claro / escuro, salvo no dispositivo.
            </Text>
          </View>
          <View style={styles.switchRow}>
            <Text style={styles.profileValue}>{theme === 'dark' ? 'Escuro' : 'Claro'}</Text>
            <Switch
              value={theme === 'dark'}
              onValueChange={toggleTheme}
              thumbColor={theme === 'dark' ? colors.primary : '#fff'}
              trackColor={{ false: '#cbd5e1', true: '#8b5cf6' }}
            />
          </View>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style={theme === 'dark' ? 'light' : 'dark'} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 80 : 0}
      >
        <ScrollView
          ref={scrollRef}
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="none"
        >
          <View style={styles.hero}>
            <Text style={styles.heroTitle}>Seu dinheiro, do seu jeito.</Text>
            <Text style={styles.heroSubtitle}>
              Visão clara das finanças com tema escuro inspirado em carteiras digitais.
            </Text>
          </View>
          {!user ? <AuthBlock /> : <Dashboard />}
        </ScrollView>
        {!user ? null : (
          <TouchableOpacity style={styles.fab} onPress={scrollToForm}>
            <Text style={styles.fabText}>+</Text>
          </TouchableOpacity>
        )}
        {drawerOpen && (
          <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={closeDrawer} />
        )}
        <Animated.View
          style={[
            styles.drawer,
            { width: drawerWidth, transform: [{ translateX: drawerAnim }] },
          ]}
        >
          <Profile />
        </Animated.View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const createStyles = (c) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: c.light,
    },
    scroll: {
      padding: 20,
    },
    hero: {
      marginBottom: 20,
      backgroundColor: c.surface,
      padding: 20,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: c.border,
    },
    heroTitle: {
      color: '#fff',
      fontSize: 22,
      fontWeight: '800',
      marginBottom: 6,
    },
    heroSubtitle: {
      color: c.hint,
      fontSize: 14,
    },
    authCard: {
      backgroundColor: c.card,
      borderRadius: 16,
      padding: 20,
      gap: 10,
      shadowColor: '#000',
      shadowOpacity: c.shadowOpacity,
      shadowRadius: 10,
      elevation: 2,
    },
    dashboard: {
      gap: 16,
    },
    title: {
      fontSize: 20,
      fontWeight: '700',
      color: c.text,
    },
    subtitle: {
      color: c.muted,
      fontSize: 14,
    },
    input: {
      backgroundColor: c.gray,
      borderRadius: 12,
      padding: 12,
      fontSize: 16,
      borderWidth: 1,
      borderColor: c.border,
      color: c.text,
      selectionColor: c.primary,
    },
    primaryButton: {
      backgroundColor: c.primary,
      padding: 14,
      borderRadius: 12,
      alignItems: 'center',
    },
    primaryButtonText: {
      color: '#fff',
      fontWeight: '700',
      fontSize: 16,
    },
    link: {
      color: c.primaryDark,
      fontWeight: '600',
      textAlign: 'center',
      marginTop: 4,
    },
    error: {
      color: c.danger,
      fontWeight: '600',
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    welcome: {
      fontSize: 20,
      fontWeight: '700',
      color: c.text,
    },
    logoutButton: {
      paddingHorizontal: 12,
      paddingVertical: 8,
      backgroundColor: c.gray,
      borderRadius: 12,
    },
    logoutText: {
      color: c.text,
      fontWeight: '600',
    },
    cardsContainer: {
      gap: 12,
    },
    card: {
      backgroundColor: c.card,
      borderRadius: 18,
      padding: 16,
      shadowColor: '#000',
      shadowOpacity: c.shadowOpacity,
      shadowRadius: 18,
      elevation: 4,
      marginBottom: 10,
      borderWidth: 1,
      borderColor: c.border,
    },
    balanceCard: {
      backgroundColor: c.light === '#080b11' ? c.gray : c.subtle,
    },
    balanceValue: {
      color: c.light === '#080b11' ? '#fff' : c.text,
      fontSize: 30,
      fontWeight: '800',
      marginVertical: 6,
    },
    cardHint: {
      color: c.muted,
    },
    cardLabel: {
      color: c.text,
      fontWeight: '600',
    },
    cardValue: {
      fontSize: 20,
      fontWeight: '800',
      color: c.text,
    },
    reportCard: {
      gap: 8,
    },
    reportHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    reportSubtitle: {
      color: c.muted,
      fontSize: 12,
      marginTop: 2,
    },
    reportBadge: {
      backgroundColor: c.gray,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: c.border,
    },
    reportBadgeText: {
      color: c.text,
      fontWeight: '700',
      fontSize: 12,
    },
    reportTotal: {
      fontSize: 28,
      fontWeight: '800',
      color: c.text,
    },
    reportHint: {
      color: c.muted,
      marginBottom: 6,
    },
    reportList: {
      gap: 10,
      marginTop: 4,
    },
    reportItem: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 6,
      borderBottomWidth: 1,
      borderColor: c.border,
    },
    row: {
      flexDirection: 'row',
      gap: 12,
    },
    smallCard: {
      flex: 1,
    },
    formCard: {
      backgroundColor: c.card,
      borderRadius: 16,
      padding: 16,
      gap: 8,
      shadowColor: '#000',
      shadowOpacity: c.shadowOpacity,
      shadowRadius: 10,
      elevation: 2,
      borderWidth: 1,
      borderColor: c.border,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: '700',
      color: c.text,
    },
    chip: {
      paddingVertical: 10,
      paddingHorizontal: 14,
      borderRadius: 12,
      backgroundColor: c.gray,
    },
    chipActiveExpense: {
      backgroundColor: c.light === '#080b11' ? '#2a1b1b' : '#fee2e2',
      borderWidth: 1,
      borderColor: c.light === '#080b11' ? '#f87171' : '#fca5a5',
    },
    chipActiveIncome: {
      backgroundColor: c.light === '#080b11' ? '#1f2a1f' : '#dcfce7',
      borderWidth: 1,
      borderColor: c.light === '#080b11' ? '#22c55e' : '#34d399',
    },
    chipText: {
      fontWeight: '700',
      color: c.text,
    },
    chipTextActive: {
      color: c.text,
    },
    listCard: {
      backgroundColor: c.card,
      borderRadius: 18,
      padding: 16,
      gap: 8,
      shadowColor: '#000',
      shadowOpacity: c.shadowOpacity,
      shadowRadius: 18,
      elevation: 4,
      marginBottom: 30,
      borderWidth: 1,
      borderColor: c.border,
    },
    transactionItem: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 10,
      borderBottomWidth: 1,
      borderColor: c.border,
    },
    expenseItem: {
      borderColor: '#fee2e2',
    },
    transactionTitle: {
      fontWeight: '700',
      color: c.text,
    },
    transactionDate: {
      color: c.muted,
      fontSize: 12,
    },
    transactionValue: {
      fontWeight: '800',
      color: c.primary,
    },
    expenseValue: {
      color: c.danger,
    },
    empty: {
      color: c.muted,
    },
    profileWrapper: {
      flexDirection: 'row',
      gap: 12,
      alignItems: 'stretch',
    },
    profileSidebar: {
      width: 110,
      backgroundColor: '#6c2bd9',
      borderRadius: 18,
      paddingVertical: 16,
      alignItems: 'center',
      gap: 12,
    },
    avatar: {
      width: 64,
      height: 64,
      borderRadius: 32,
      backgroundColor: '#f5f3ff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    avatarText: {
      color: '#4c1d95',
      fontWeight: '800',
      fontSize: 22,
    },
    sidebarItem: {
      width: '100%',
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      paddingHorizontal: 14,
      paddingVertical: 10,
    },
    sidebarIcon: {
      fontSize: 16,
      color: '#f8fafc',
    },
    sidebarText: {
      color: '#f8fafc',
      fontWeight: '700',
      fontSize: 13,
    },
    sidebarLogout: {
      marginTop: 'auto',
      width: '100%',
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      paddingHorizontal: 14,
      paddingVertical: 10,
    },
    sidebarLogoutText: {
      color: '#f8fafc',
      fontWeight: '700',
      fontSize: 13,
    },
    profileCard: {
      flex: 1,
      minWidth: 220,
      backgroundColor: c.card,
      borderRadius: 16,
      padding: 16,
      gap: 12,
      shadowColor: '#000',
      shadowOpacity: c.shadowOpacity,
      shadowRadius: 10,
      elevation: 2,
      borderWidth: c.light === '#0b1220' ? 1 : 0,
      borderColor: c.border,
    },
    profileRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 10,
    },
    profileLabel: {
      color: c.muted,
      fontWeight: '600',
    },
    profileValue: {
      color: c.text,
      fontWeight: '700',
    },
    profileHint: {
      color: c.muted,
      fontSize: 12,
      marginTop: 4,
    },
    divider: {
      height: 1,
      backgroundColor: c.border,
      marginVertical: 4,
    },
    switchRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    backdrop: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.25)',
    },
    drawer: {
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: 0,
      backgroundColor: c.card,
      padding: 14,
      paddingTop: 24,
      shadowColor: '#000',
      shadowOpacity: 0.25,
      shadowRadius: 12,
      elevation: 10,
      borderRightWidth: 1,
      borderColor: c.border,
    },
    avatarButton: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: c.gray,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
      borderColor: c.border,
    },
    avatarButtonText: {
      color: c.text,
      fontWeight: '800',
    },
    overviewCard: {
      gap: 10,
    },
    overviewRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 10,
      paddingVertical: 4,
    },
    overviewLabel: {
      flex: 1,
      color: c.muted,
      fontWeight: '600',
    },
    overviewValue: {
      color: c.text,
      fontWeight: '700',
    },
    bar: {
      width: 6,
      height: 28,
      borderRadius: 12,
    },
    barSmall: {
      width: 6,
      height: 20,
      borderRadius: 10,
    },
    alertCard: {
      gap: 8,
    },
    fab: {
      position: 'absolute',
      right: 20,
      bottom: 30,
      backgroundColor: c.primary,
      width: 56,
      height: 56,
      borderRadius: 28,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: '#000',
      shadowOpacity: 0.2,
      shadowRadius: 12,
      elevation: 6,
    },
    fabText: {
      color: '#fff',
      fontSize: 28,
      fontWeight: '800',
      marginTop: -2,
    },
  });
